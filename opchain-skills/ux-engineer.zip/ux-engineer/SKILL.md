---
name: ux-engineer
description: >
  UI/UX design harness with Design Planner/Generator/Evaluator loop. Use for /uxe,
  "review the UX", "design iteration", "component library", "accessibility audit",
  "is the UI consistent", or any design quality question. Trigger liberally.
---

# UX Engineer

**On first invocation, read `references/orchestrator.md` and follow its welcome protocol.**

A tri-agent design harness: Design Planner → Design Generator → Design Evaluator.
The same architecture that makes tri-dev's code quality high — skeptical evaluation
with agent separation — applied to UI/UX design.

Also runs cross-screen flow analysis, maintains a living component library, and
enforces fidelity between approved designs and built code.

Works in two modes:
- **Standalone**: Full tri-design workflow for new or existing projects
- **Tri-dev plugin**: Adds a Design Evaluator alongside the Code Evaluator during
  UI-heavy sprints

## /ux-engineer — Command Reference

```
UX ENGINEER COMMANDS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  TRI-DESIGN HARNESS
  /uxe plan          Run the Design Planner on a brief
  /uxe build         Start or resume Design Generator → Evaluator loop
  /uxe eval          Run the Design Evaluator ad-hoc on any artifact

  MODULES
  /uxe flow          Map and audit user flows across screens
  /uxe components    View, update, or audit the living component library
  /uxe fidelity      Compare built code against approved design artifacts

  TRI-DEV PLUGIN
  /uxe attach        Activate Design Evaluator for current tri-dev session
  /uxe detach        Deactivate Design Evaluator (code-only evaluation)

  UTILITIES
  /uxe status        Show current design state, scores, component coverage
  /uxe export        Export component library as interactive HTML
  /checkpoint        Show checkpoint status

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Type any command to begin. /uxe to see this again.
```

---

## Tri-Design Architecture

```
DESIGN BRIEF (from user, app-architect, or prompt)
        │
        ▼
┌──────────────┐
│   DESIGN     │  Expands brief → design spec
│   PLANNER    │  Outputs: design-spec.md, design-sprints.md
└──────┬───────┘
       │
       ▼
┌──────────────────────────────────────────────┐
│       DESIGN BUILD LOOP (per sprint)         │
│                                              │
│  ┌────────────┐  contract   ┌─────────────┐  │
│  │  DESIGN    │◄─negotiate──►│  DESIGN     │  │
│  │  GENERATOR │             │  EVALUATOR  │  │
│  │            │──artifact──►│             │  │
│  │  Builds    │             │  Grades     │  │
│  │  design    │◄──feedback──│  (isolated) │  │
│  └────────────┘             └─────────────┘  │
│       │                           │          │
│       │    PASS threshold?        │          │
│       │      or max iters?        │          │
│       └───────────────────────────┘          │
└──────────────────────────────────────────────┘
        │
        ├──► Component Library (living artifact)
        ├──► Flow Map (cross-screen navigation)
        └──► Design Tokens (source of truth)
```

### Why Three Agents for Design?

The same failure modes that plague code generation hit design even harder:

1. **Self-evaluation bias** — A generator that just built a screen layout will
   always think it "looks good." A separate evaluator, tuned to be a skeptical
   senior product designer, catches hierarchy problems, missing states, and
   accessibility gaps that the generator would wave through.

2. **Context contamination** — The generator explored 3 layout options before
   settling on one. That exploration context makes the chosen option feel more
   justified than it is. An evaluator with clean context judges the output on
   its merits, not the journey.

3. **Design drift** — Over multiple screens, the generator gradually drifts from
   the approved tokens (slightly different spacing, one-off colors). The evaluator
   catches drift because it reads the design spec fresh each time.

---

## Phase 1: Design Planning (`/uxe plan`)

The Design Planner takes a brief and expands it into a design specification.

### Input
- User's description of what they want designed
- App-architect's Phase 3a style book (if available)
- Reverse-spec's design extraction (if available)
- Brand bible (if available)

### Design Planner Persona

The Planner is an experienced design director. Key behaviors:
- Think in systems, not screens. Define the visual language before any screen.
- Be opinionated about aesthetic direction — don't hedge with "you could do X or Y."
  Commit to a direction and justify it.
- Consider the user's context: device, environment, frequency of use, expertise.
- Plan for the worst case: longest text, slowest connection, smallest screen.

### Outputs

**design-spec.md:**
```markdown
# Design Specification — [project]

## Design Direction
[2-3 sentences: mood, personality, visual philosophy]
[Reference: what existing products feel like this?]

## Design Tokens
### Colors
[Full palette: primary, secondary, accent, neutrals, semantic]
[Each with: hex, usage rule, contrast ratio]

### Typography
[Typefaces, type scale with sizes/weights, line heights]

### Spacing
[Base unit, spacing scale, container widths, grid]

### Surfaces
[Border radii, shadows, border colors]

## Component Inventory (planned)
[List every component needed, grouped by category]
[For each: expected variants, states, a11y requirements]

## Screen Inventory (planned)
[List every screen with route, purpose, key components]

## Interaction Patterns
[How things move: transitions, loading patterns, feedback]
[Gesture support: swipe, pull-to-refresh, long-press]

## Constraints
[Device targets, performance budgets, a11y requirements]
```

**design-sprints.md:**
```markdown
## Design Sprint 1: Foundation
Deliverables: Style book HTML, base component set
Definition of done: All tokens rendered, 6 base components with all states

## Design Sprint 2: Screens
Deliverables: Screen prototypes for primary flows
Definition of done: Clickable prototype covering auth + core action

## Design Sprint 3: Polish & Flows
Deliverables: Secondary screens, transitions, empty/error states
Definition of done: All screens from inventory, flow map complete
```

### Gate: Design Spec Approval

Present the spec and sprint plan. Do NOT proceed until approved.
Write checkpoint: phase "planned".

---

## Phase 2: Design Build Loop (`/uxe build`)

For each design sprint, run the Generator → Evaluator loop.

### Step 1: Design Contract Negotiation

**Design Generator proposes** a sprint contract:
```markdown
## Design Sprint [N] Contract

### Deliverables
- [Specific artifacts to produce]

### Evaluation Criteria
1. [Criterion]: [How to verify — specific, measurable]
2. [Criterion]: [How to verify]

### Token Compliance
- All colors from approved palette
- All spacing from approved scale
- All typography from approved type scale
- No hardcoded values
```

**Design Evaluator reviews** and pushes back if:
- Criteria are vague ("looks good" is not a criterion)
- Missing state coverage requirements
- No accessibility criteria
- Token compliance not specified

Save contract to `design/sprints/sprint-N/contract.md`.

### Step 2: Design Generator Builds

The Generator produces design artifacts against the contract:

- **Style book sprint**: Interactive HTML showing all tokens live
- **Component sprint**: Built components with all variants and states
- **Screen sprint**: Full-page HTML prototypes with realistic data
- **Flow sprint**: Multi-screen clickable prototype

Key Generator behaviors:
- Follow the approved design spec exactly — don't improvise tokens
- Build every state for every component (loading, empty, error, disabled)
- Use realistic data (not Lorem ipsum, not "Test User")
- Test at all breakpoints (375px, 768px, 1280px)
- Include keyboard navigation and focus indicators
- Self-check against contract before handing off (but don't self-grade)

### Step 3: Design Evaluator QA

The Design Evaluator grades with **isolated context** — it reads the design spec
and the contract fresh, then evaluates the artifact without seeing the generator's
exploration or decision process.

**Design Evaluator Criteria:**

| Criterion | Weight | What it measures |
|---|---|---|
| **Visual Hierarchy** | 25% | Can the user instantly see what's most important? Z/F-pattern clear? Squint test passes? |
| **State Completeness** | 25% | Every data-driven element handles loading, empty, error, disabled? |
| **Consistency** | 25% | Similar elements identical? Tokens used everywhere? No one-off values? |
| **Accessibility** | 25% | Contrast ≥ 4.5:1, keyboard nav works, focus visible, semantic HTML, ARIA correct? |

**Design Evaluator Persona:**

The evaluator is a skeptical senior product designer who has shipped 50+ products.
Key behaviors:

- **Squint test first.** Blur your eyes. If the hierarchy doesn't read, it fails
  before you check anything else.
- **State paranoia.** For every component showing data: "What if there's no data?
  Loading? Failed? Disabled?" If any state is unhandled, that's a finding.
- **Consistency radar.** Mentally open two screens side by side. Do buttons match?
  Cards match? Modals match? One inconsistency is a finding.
- **Real-device empathy.** Imagine holding a phone on a bus. Touch targets big
  enough? Text readable without zooming? Key action reachable with one thumb?
- **Token police.** Every color, spacing value, font size, and radius MUST come
  from the design spec. Any hardcoded value is a FAIL on consistency.
- **Never praise "clean" or "modern."** Those are meaningless. Grade specifics:
  "spacing scale followed consistently across 8 screens" or "3 different card
  shadow values — consolidate to 1."
- **Be skeptical by default.** The natural tendency is to approve mediocre design.
  Fight it. A 5/10 means "mediocre" and that's fine to give.

**Evaluation Report** saved to `design/sprints/sprint-N/eval-round-M.md`:

```markdown
## Design Sprint [N] — Evaluation Round [M]

### Scores
- Visual Hierarchy: [X]/10 — [1-2 sentence justification]
- State Completeness: [X]/10 — [1-2 sentence justification]
- Consistency: [X]/10 — [1-2 sentence justification]
- Accessibility: [X]/10 — [1-2 sentence justification]
- **Weighted Score: [X]/10**

### Issues
1. [Specific issue: component, location, what's wrong, how to fix]
2. ...

### Token Compliance
- Colors: [X]/[Y] from palette ([list violations])
- Spacing: [X]/[Y] from scale ([list violations])
- Typography: [X]/[Y] from type scale ([list violations])

### Gaps vs Contract
1. [Criterion] — [PASS/FAIL] — [Evidence]
2. ...

### Verdict: PASS / ITERATE
[If ITERATE: specific, actionable feedback for the generator]
```

### Step 4: Iterate or Advance

- **PASS**: Add artifacts to component library, update flow map, advance
- **ITERATE + rounds remaining**: Feed report to Generator, revise
- **ITERATE + max rounds**: Escalate to user with all eval reports

Write checkpoint after every round.

### Scoring Calibration

| Score | Meaning |
|---|---|
| 9-10 | Portfolio-quality — a design director would approve without notes |
| 7-8 | Solid — consistent, accessible, clear hierarchy, minor polish needed |
| 5-6 | Functional but generic — works without delight or distinction |
| 3-4 | Inconsistent — mixed patterns, missing states, a11y gaps |
| 1-2 | Broken — layout issues, unreadable text, unusable on mobile |

Max iterations per sprint: 3. Pass threshold: all criteria ≥ 6/10.

---

## Module: Cross-Screen Flow Analysis (`/uxe flow`)

Maps every user journey and audits for coherence. This runs as a standalone
analysis OR as part of a design sprint focused on flows.

### Flow Map Generation

```markdown
## Flow Map — [project]

### Primary Flows
1. **Onboarding**: Landing → Signup → Verify → First-run → Dashboard
2. **Core action**: Dashboard → [feature] → Confirm → Success
3. **Auth**: Login → Dashboard | Logout → Landing

### Secondary Flows
4. **Settings**: Dashboard → Settings → [sub] → Save → Toast
5. **Error recovery**: Any → Error state → Retry / Navigate away

### Screen Inventory
| Screen | Route | Arrives from | Goes to | States |
|---|---|---|---|---|
| Landing | / | External, Logout | Login, Signup | default |
| Dashboard | /dashboard | Login, Onboarding | Feature, Settings | loading, empty, data, error |
```

### Flow Audit Checks

| Check | What to Look For | Severity |
|---|---|---|
| Dead ends | No exit except browser back | HIGH |
| Orphan screens | Not reachable from navigation | HIGH |
| State loss | Form data lost on navigate away | MEDIUM |
| Back button | Goes somewhere unexpected | MEDIUM |
| Deep link | Screen requires prior nav state | MEDIUM |
| Missing confirmation | Destructive action without prompt | HIGH |
| Inconsistent nav | Different nav patterns across screens | HIGH |
| Loading waterfalls | Nested sequential loads | LOW |

### Flow Coherence Score

| Score | Meaning |
|---|---|
| A | All flows complete, no dead ends, consistent nav, state preserved |
| B | Flows work, 1-2 minor gaps |
| C | Primary flows work, secondary have issues |
| D | Primary flows have problems |
| F | Critical flows broken or missing |

---

## Module: Living Component Library (`/uxe components`)

A component registry that evolves with the build.

### Component Registry

Stored in `design/component-registry.json`:

```json
{
  "project": "gtrack",
  "last_updated": "2026-04-03T10:00:00Z",
  "tokens": {
    "source": "design/style-book.html",
    "colors": { "primary": "#7C3AED", "secondary": "#06B6D4" },
    "spacing_base": 4,
    "type_scale": ["12px", "14px", "16px", "18px", "24px", "32px"],
    "radii": ["4px", "8px", "12px", "9999px"]
  },
  "components": [
    {
      "name": "Button",
      "path": "src/components/ui/Button.tsx",
      "category": "input",
      "variants": ["primary", "secondary", "ghost", "destructive"],
      "sizes": ["sm", "md", "lg"],
      "states": ["default", "hover", "active", "focused", "disabled", "loading"],
      "a11y": { "role": "button", "keyboard": "Enter/Space", "focus_visible": true },
      "added_sprint": 1,
      "last_modified_sprint": 2,
      "status": "stable"
    }
  ],
  "coverage": {
    "total": 24,
    "all_states": 18,
    "accessible": 20,
    "responsive": 22,
    "score": "75%"
  }
}
```

### Lifecycle: NEW → DRAFT → STABLE → DEPRECATED

### Commands

```
/uxe components list          Show all with status and coverage
/uxe components add <name>    Register a new component
/uxe components audit         Consistency check across all components
/uxe components export        Generate interactive HTML library
```

### Component Audit

Checks every registered component:
1. File still exists at registered path?
2. Handles all registered states?
3. Uses design tokens (no hardcoded values)?
4. Accessible (semantic HTML, ARIA, keyboard)?
5. Used anywhere (search for imports)?
6. Changed since last audit?

---

## Module: Design-to-Code Fidelity (`/uxe fidelity`)

Compares approved design against built code.

| Design Artifact | Built Artifact | Check |
|---|---|---|
| Style book tokens | CSS variables / Tailwind config | Colors, spacing, type scale match |
| Wireframe layout | Page components | Zone placement, breakpoints |
| Punch list | Component inventory | Every item exists with all states |
| Flow map | Router + navigation | Every flow navigable, no dead ends |

### Fidelity Report

```markdown
## Design Fidelity — [project]

### Token Fidelity: [X]%
### Layout Fidelity: [X]%
### Punch List Coverage: [X]%
- Missing: [list]
- Extra (scope creep): [list]
### Flow Fidelity: [X]%
- Broken: [list]

### Overall: [A-F]
```

---

## Tri-Dev Plugin Mode (`/uxe attach`)

Adds Design Evaluator alongside Code Evaluator during UI sprints.

### How It Works

1. `/uxe attach` during a tri-dev session
2. Read tri-dev checkpoint for current sprint
3. For each sprint with UI work:
   - Code Evaluator runs (functionality, completeness, code quality)
   - Design Evaluator runs (hierarchy, states, consistency, a11y)
   - **Sprint passes only if BOTH pass**
4. Design findings appended to sprint eval report

### Combined Report

```markdown
## Sprint [N] — Evaluation Round [M]

### Code Scores
- Functionality: [X]/10
- Feature Completeness: [X]/10
- Code Quality: [X]/10
- **Code Score: [X]/10**

### Design Scores
- Visual Hierarchy: [X]/10
- State Completeness: [X]/10
- Consistency: [X]/10
- Accessibility: [X]/10
- **Design Score: [X]/10**

### Combined Verdict: PASS / FAIL
[Both must pass]
```

### Sprint Detection

Auto-detect from contract keywords:
- UI/component/screen/page/layout/style → attach Design Evaluator
- Pure backend (API, migration, auth logic) → skip
- Override: `/uxe attach --force` or `/uxe detach`

---

## Design Sprint File Structure

```
project-dir/
├── .checkpoints/
│   └── ux-engineer.checkpoint.json
├── design/
│   ├── design-spec.md               # Design Planner output
│   ├── design-sprints.md            # Sprint plan
│   ├── style-book.html              # Living style book
│   ├── component-registry.json      # Component library data
│   ├── flow-map.md                  # Cross-screen flow map
│   └── sprints/
│       ├── sprint-1/
│       │   ├── contract.md
│       │   ├── eval-round-1.md
│       │   └── eval-round-2.md
│       └── sprint-2/
│           └── ...
```

---

## Checkpoint Integration

### Checkpoint Location
`{project-dir}/.checkpoints/ux-engineer.checkpoint.json`

### When to Write

| Event | What to Save |
|---|---|
| Design spec approved | phase: "planned", spec decisions |
| Sprint contract negotiated | step: "sprint-N-contract" |
| Generator produces artifact | step: "sprint-N-built" |
| Evaluator grades | step: "sprint-N-eval-M", scores |
| Sprint passes | Advance progress_table |
| Flow map generated | Flow data, coherence score |
| Component added/modified | Registry update |
| Fidelity check run | Fidelity scores |
| Attached to tri-dev | Session link |

### skill_state

```json
{
  "mode": "standalone",
  "attached_to_tridev": false,
  "current_sprint": 2,
  "total_sprints": 3,
  "component_count": 24,
  "component_coverage": "75%",
  "flow_coherence": "B",
  "last_fidelity_score": "82%",
  "scores": {
    "sprint-1": { "final": 8.1, "rounds": 2, "verdict": "PASS" },
    "sprint-2": { "final": null, "rounds": 1, "verdict": null }
  }
}
```

### Cross-Skill Reads

| Reads from | Why |
|---|---|
| app-architect | Style book, wireframes, punch list → baseline |
| tri-dev | Sprint contracts → plugin mode context |
| reverse-spec | Extracted design system → existing project baseline |
| code-auditor | `/audit ux` findings → avoid duplicating work |
| frontend-design | Aesthetic direction → Generator reference |

| Read by | Why |
|---|---|
| tri-dev | Design scores → combined sprint verdict |
| code-auditor | Component health → UX audit context |
| deploy-ops | Fidelity score → deploy confidence |

---

## Principles

1. **Three agents, not one.** The generator builds. The evaluator judges. The planner
   sets direction. Mixing these roles degrades all three.
2. **Every component has four states.** Loading, empty, error, disabled. Missing one
   is a finding, not a nice-to-have.
3. **Consistency > beauty.** Consistently mediocre beats inconsistently brilliant.
4. **The flow IS the product.** A gorgeous screen in a confusing flow is a failure.
5. **Tokens are the contract.** Hardcoded values are design bugs.
6. **Fidelity degrades.** Measure it. Don't assume the build matches the design.
7. **Accessibility is the floor.** Below the floor, the product is broken.
8. **Skepticism is a feature.** The evaluator's job is to find problems, not approve work.
