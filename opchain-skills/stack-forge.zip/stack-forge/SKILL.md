---
name: stack-forge
description: >
  Stack advisor for any platform: Cloudflare, Vercel, AWS, Supabase, Rails, Django.
  Use for /stack, /stack-decide, /feature, "what stack", "tech stack", "what should I
  build with", or framework comparisons. Auto-invoked by app-architect. Trigger liberally.
---

# Stack Forge

**On first invocation, read `references/orchestrator.md` and follow its welcome protocol.**

Opinionated stack advisor that helps you pick the right tools and enforces type safety
across whatever stack you choose. Auto-invoked by app-architect during Phase 2 — you
don't call it separately for new projects.

Works with any stack: Cloudflare Workers, Vercel/Next.js, AWS Lambda, Supabase, Rails,
Django, Go, Rust — the decision framework is universal. The implementation patterns are
stack-specific, loaded from reference docs at runtime.

## How This Skill Fits the Build Pipeline

```
APP-ARCHITECT (planning)                TRI-DEV (building)
  Phase 2: Spec ──auto-calls──▶ stack-forge decision tree
  Phase 5: Scaffold ──auto-calls──▶ stack-forge project structure
                                         │
  Feature request ───────────────────────▶ /feature → sprint decomposition
                                         │
                                   Planner reads feature-decomposition
                                   Generator reads stack-specific patterns
                                   Evaluator reads per-layer criteria
```

**App-architect auto-invokes stack-forge** — when Phase 2 starts, stack-forge's decision
tree runs automatically to generate `01-tech-stack.md` and `02-architecture.md`. The user
doesn't need to call `/stack-forge` separately. Stack-forge reads the discovery interview
results and recommends the best stack for the project's requirements.

**Tri-dev uses stack-forge** for stack-ordered sprint decomposition regardless of stack choice.

---

## /stack-forge — Command Reference

```
STACK FORGE COMMANDS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  STACK SELECTION
  /stack-decide     Run the full stack decision tree
  /stack-compare    Compare 2-3 specific stack options side by side

  PATTERNS
  /typed-pipeline   Set up type chain for the selected stack
  /testing          Configure testing pyramid for the stack
  /deploy           Deployment patterns for the selected platform
  /errors           Error handling + logging patterns
  /ci               CI pipeline for the stack

  TRI-DEV INTEGRATION
  /feature          Decompose a feature into stack-ordered sprints

  SESSION
  /checkpoint       Show checkpoint status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Stack Decision Tree (`/stack-decide`)

### How It Works

The decision tree adapts to the project. It doesn't assume Cloudflare or any platform —
it starts from requirements and narrows down. Skip questions where the answer is already
clear from app-architect discovery, user memory, or conversation context.

**Before answering any question, web search for current best practices.** Frameworks
change fast — a recommendation from 6 months ago may be wrong today. Search for
"[framework] production readiness 2026" or "[A] vs [B] for [use case]" before committing.

### Question 1: Platform & Hosting

Start here because it constrains everything downstream.

| Factor | Ask |
|---|---|
| Deployment target | Where does this run? Edge (CF Workers, Vercel Edge), serverless (Lambda, Cloud Run), container (Fly.io, Railway), VPS (DigitalOcean), or managed PaaS (Heroku, Render)? |
| User geography | Global (needs edge/CDN) or regional (single-region fine)? |
| Budget | Free tier required? What's the monthly ceiling? |
| Existing infra | Is the team already on AWS/GCP/CF/Vercel? Don't migrate without reason. |
| Compliance | HIPAA, SOC2, GDPR data residency? This eliminates some platforms. |

**Decision heuristic:**
- Solo/small app, free tier matters → **Cloudflare Workers** or **Vercel Hobby**
- Next.js app → **Vercel** (native support) or **CF Pages** (cost)
- Heavy backend logic, Python/ML → **Cloud Run** or **Fly.io**
- Enterprise, existing AWS → **Lambda + API Gateway** or **ECS**
- Full-stack with auth/storage built in → **Supabase** or **Firebase**
- If unsure → **start with the smallest thing that works.** Migrate later when you hit a wall.

### Question 2: Backend Language & Framework

| Factor | TypeScript | Python | Go | Ruby | Rust |
|---|---|---|---|---|---|
| Best for | API-first, full-stack JS, edge | Data/ML, scripting, rapid proto | Performance, infra tools | Rapid web apps, convention | Systems, WASM, extreme perf |
| Frameworks | Hono, Express, Fastify, tRPC, Next.js API | FastAPI, Django, Flask | Chi, Fiber, Echo | Rails, Sinatra | Axum, Actix |
| Type safety | Native (TS) | Pydantic, mypy | Native | Sorbet (optional) | Native |
| ORM | Drizzle, Prisma | SQLAlchemy, Django ORM | GORM, sqlx | ActiveRecord | Diesel, SeaORM |
| Edge deploy | Workers, Vercel Edge | Workers (beta), Lambda | Lambda, Fly.io | Not typical | Workers (WASM), Lambda |

**Decision heuristic:**
- Full-stack JS/TS, API + frontend same language → **TypeScript**
- Data processing, ML features, scripting → **Python**
- Performance-critical microservice → **Go** or **Rust**
- Rapid prototype, "I need this by Friday" → **Rails** or **Next.js**
- Team's strongest language wins unless there's a compelling technical reason otherwise

### Question 3: Database

| Factor | SQLite/D1 | Postgres | MySQL | MongoDB | Redis |
|---|---|---|---|---|---|
| Scale | Small-medium | Any scale | Any scale | Document-heavy | Cache/queue |
| Hosted options | D1, Turso, Litestream | Supabase, Neon, RDS | PlanetScale, RDS | Atlas, self-hosted | Upstash, Elasticache |
| Cost (entry) | Free | Free (Supabase/Neon) | Free (PlanetScale) | Free (Atlas) | Free (Upstash) |
| Best for | Solo/small apps | Most production apps | Legacy, WordPress | Flexible schema | Caching, sessions, queues |
| ORM support | Drizzle, Prisma | All ORMs | All ORMs | Mongoose | ioredis |

**Decision heuristic:**
- < 100 users, simple schema → **SQLite/D1** (zero ops)
- Production app, complex queries, RLS → **Postgres** (Supabase or Neon for free tier)
- Need flexible schema, document storage → **Mongo** (but usually Postgres JSONB is enough)
- Caching layer needed → add **Redis/Upstash** alongside primary DB

### Question 4: Auth

| Option | Best for | Complexity | Lock-in |
|---|---|---|---|
| Passkeys (WebAuthn) | 1-2 known users, passwordless | Medium | None |
| NextAuth / Auth.js | Next.js apps, OAuth providers | Low-Medium | Low |
| Supabase Auth | Full Supabase stack, magic links | Low | Medium |
| Clerk | Polished auth UI, enterprise SSO | Low | High |
| Lucia Auth | Self-hosted, full control | Medium | None |
| Firebase Auth | Google ecosystem | Low | High |
| Platform-native | CF Access, AWS Cognito | Low-Medium | High |
| Roll your own | Never, unless you have a specific reason | High | None |

**Decision heuristic:**
- Using Supabase? → **Supabase Auth**
- Using Next.js? → **Auth.js** or **Clerk**
- 1-2 known users → **Passkeys**
- Internal tool behind corp network → **Platform-native** (CF Access, AWS SSO)
- Need full control → **Lucia**
- Enterprise SSO required → **Clerk** or **Auth0**

### Question 5: Frontend

| Option | Best for | SSR | Complexity |
|---|---|---|---|
| Next.js | Full-stack React, SEO | Yes | Medium |
| React + Vite | SPA, dashboard-style apps | No (client) | Low |
| SvelteKit | Performance, smaller bundle | Yes | Low-Medium |
| Astro | Content sites, marketing pages | Yes (islands) | Low |
| Vue + Nuxt | Vue ecosystem | Yes | Medium |
| HTMX + server templates | Progressive enhancement, Rails-style | Server | Low |
| No frontend | Pure API, CLI tool, mobile backend | N/A | N/A |

### Output: Stack Recommendation

After the decision tree, produce a summary:

```markdown
## Stack Recommendation — [project]

| Layer | Choice | Rationale | Alternatives Considered |
|---|---|---|---|
| Platform | Vercel | Next.js native, generous free tier | CF Pages (cheaper), AWS (team uses it) |
| Backend | Next.js API Routes (TS) | Same language as frontend, tRPC available | FastAPI (if Python needed) |
| Database | Postgres (Supabase) | Auth included, RLS, free tier | D1 (simpler), Neon (standalone) |
| Auth | Supabase Auth | Built-in with DB, magic links | Auth.js (more providers) |
| Frontend | Next.js + React | SSR for SEO, app router | SvelteKit (lighter) |
| Hosting | Vercel | Zero-config for Next.js | CF Pages, Fly.io |

### Estimated Monthly Cost
| Tier | Users | Cost |
|---|---|---|
| Free | < 100 | $0 |
| Growth | 100-1K | $20-50 |
| Scale | 1K+ | $50-200 |
```

When invoked by app-architect, this output becomes `01-tech-stack.md`.

---

## Typed Pipeline (Universal)

Regardless of stack, the principle is the same: **DB schema is truth, everything
downstream is derived.**

```
DB Schema → ORM Types → API Types → API Spec (OpenAPI) → Generated Client Types → Frontend
    ↑                                                                                  │
    └──────────────── Never hand-edit generated types ─────────────────────────────────┘
```

### Per-Stack Type Chains

| Stack | DB → Types | API Spec | Client Gen |
|---|---|---|---|
| Hono + D1 | Drizzle schema → inferred TS | Zod → OpenAPI via @hono/zod-openapi | openapi-fetch |
| Next.js + Supabase | Supabase CLI → generated types | tRPC (type-safe by default) | tRPC client |
| FastAPI + Postgres | SQLAlchemy → Pydantic models | Auto-generated OpenAPI | openapi-typescript |
| Django + Postgres | Django models → serializers | DRF + drf-spectacular | openapi-typescript |
| Rails + Postgres | ActiveRecord → schema.rb | Rswag / committee | openapi-typescript |
| Go + Postgres | sqlc → generated Go types | swaggo/gin-swagger | openapi-typescript |

Read `references/typed-pipeline.md` for detailed implementation per stack.

---

## Testing Strategy (Universal)

| Level | Ratio | What It Catches |
|---|---|---|
| Contract tests | Run every PR | API spec violations, edge-case 500s |
| Unit tests | ~60% | Logic bugs, data transforms |
| Integration tests | ~25% | API flows, DB interactions |
| E2E tests | ~15% | User flows, visual regression |

**For any stack, start with:** contract tests + unit tests on critical paths. Add E2E
only for critical user flows. Don't over-test a 2-user app.

Read `references/testing-patterns.md` for framework-specific tooling.

---

## Deployment Patterns (Per-Platform)

| Platform | Deploy Command | CI/CD | Preview Deploys |
|---|---|---|---|
| CF Workers | `wrangler deploy` | GitHub Actions | `wrangler deploy --env staging` |
| Vercel | `git push` (auto) | Built-in | Automatic per PR |
| Fly.io | `fly deploy` | GitHub Actions | `fly deploy --app staging` |
| AWS Lambda | `cdk deploy` or `serverless deploy` | GitHub Actions | Separate stage |
| Railway | `git push` (auto) | Built-in | Automatic per PR |
| Cloud Run | `gcloud run deploy` | Cloud Build | Traffic splitting |

Read `references/deployment-patterns.md` for detailed patterns per platform.

---

## Feature Decomposition (`/feature`)

Decomposes a feature into stack-ordered sprints for tri-dev regardless of platform:

```
1. DB layer (schema, migrations)
2. API layer (endpoints, types, validation)
3. Type generation (if applicable — OpenAPI, tRPC, codegen)
4. Frontend (components, pages, state)
5. Tests (unit, integration, contract)
6. CI/CD (deploy pipeline, type enforcement)
```

The sprint order follows the type pipeline — bottom-up, each layer built on
verified ground truth. This ordering is universal across stacks.

---

## App-Architect Auto-Invocation

**Stack-forge is automatically called by app-architect during Phase 2.** The flow:

1. App-architect completes Phase 1 (discovery interview)
2. Phase 2 starts → app-architect reads stack-forge's decision tree
3. Stack-forge runs the decision tree using discovery context (requirements, users,
   constraints, budget, team experience)
4. Stack-forge produces the stack recommendation
5. App-architect writes `01-tech-stack.md` and `02-architecture.md` using stack-forge's output
6. User reviews stack at the Spec Approval Gate

**The user never needs to call `/stack-forge` separately for new projects.** It happens
inside app-architect. `/stack-forge` is only needed standalone for:
- Quick stack questions outside a project context
- Feature decomposition (`/feature`) for existing projects
- Gap analysis on existing codebases (with reverse-spec)

---

## Session Persistence (Checkpoint Protocol)

Checkpoint location: `{project-dir}/.checkpoints/stack-forge.checkpoint.json`

### When to Write

| Event | What to Save |
|---|---|
| Each decision tree question answered | Decision + rationale |
| Decision tree complete | Full recommendation, stack path |
| Feature decomposition generated | Sprint plan reference |
| Gap analysis completed | Findings summary |

### skill_state

```json
{
  "stack_path": "nextjs-supabase",
  "decisions": {
    "platform": { "choice": "Vercel", "rationale": "Next.js native" },
    "backend": { "choice": "Next.js API Routes", "rationale": "Full-stack TS" },
    "database": { "choice": "Supabase Postgres", "rationale": "Auth included, free tier" },
    "auth": { "choice": "Supabase Auth", "rationale": "Built-in" },
    "frontend": { "choice": "Next.js + React", "rationale": "SSR, app router" }
  },
  "features_planned": [],
  "gap_analysis_done": false
}
```

### Cross-Skill Reads

| Reads from | Why |
|---|---|
| app-architect | Discovery interview → stack decision context |
| reverse-spec | Existing stack → gap analysis baseline |

| Read by | Why |
|---|---|
| app-architect | Stack recommendation → Phase 2 spec (automatic) |
| tri-dev | Sprint decomposition patterns |
| code-auditor | Type pipeline standard → compliance check |
| scale-ops | Platform limits → scaling constraints |
| deploy-ops | Platform → deployment patterns |

---

## Reference Docs

| Command | Reference | Contents |
|---|---|---|
| /typed-pipeline | `references/typed-pipeline.md` | Type chains per stack |
| /testing | `references/testing-patterns.md` | Testing pyramid per framework |
| /deploy | `references/deployment-patterns.md` | Deploy patterns per platform |
| /errors | `references/error-handling.md` | Structured errors, logging |
| /feature | `references/feature-decomposition.md` | Sprint templates for tri-dev |
| — | `references/cf-deployment.md` | CF-specific patterns (Workers, D1, KV) |

**When a reference doc doesn't cover the selected stack**, web search for current
best practices and generate the pattern inline. The reference docs are a starting
point, not a ceiling.

---

## Principles

1. **Start with the smallest stack that works.** SQLite before Postgres. Vercel before
   AWS. Monolith before microservices. Upgrade when you hit a real wall.
2. **One-direction type flow.** DB schema is truth. Everything downstream is derived.
3. **Web search before recommending.** Frameworks change. Don't recommend based on
   stale training data — search for current status.
4. **CI is the enforcer.** If it's not in CI, it's a suggestion, not a rule.
5. **The team's stack wins.** Unless there's a compelling technical reason, match what
   the team already knows. Migration cost > marginal framework benefit.
6. **Automatic, not optional.** Stack decisions happen inside app-architect Phase 2,
   not as a separate step the user might forget.
