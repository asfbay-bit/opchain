---
name: code-auditor
description: >
  Code quality auditor with Auditor/Fixer/Verifier loop. Use for /audit, "audit this",
  "find bugs", "security audit", "code review", "pre-deploy check", "what's wrong with
  this code", or any code quality question. Trigger liberally.
---

# Code Auditor

**On first invocation, read `references/orchestrator.md` and follow its welcome protocol.**

Tri-agent code quality system: Auditor finds problems → Fixer proposes remediations →
Verifier confirms the fixes actually solve the findings (not just cosmetic reshuffles).

The Auditor-only mode (`/audit`) runs a one-pass sweep and produces a findings report.
The full harness (`/audit fix-all`) chains all three agents for find → fix → verify.

## /audit — Command Reference

```
CODE AUDITOR COMMANDS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  SWEEP MODES
  /audit full            Full codebase sweep — all categories
  /audit security        Security-focused (auth, injection, secrets, CORS)
  /audit perf            Performance (N+1, bundle, caching, queries)
  /audit quality         Code quality (dead code, complexity, patterns)
  /audit ux              UX/accessibility (a11y, states, consistency, responsive)
  /audit pre-deploy      Pre-deployment gate (security + perf + config)
  /audit file [path]     Audit specific file(s)
  /audit diff            Audit git diff or staged changes

  TRI-AGENT HARNESS
  /audit fix-all         Run full Auditor → Fixer → Verifier loop
  /audit fix <id>        Fix a single finding with verification
  /audit verify          Re-run Verifier on previous fixes

  BOOTSTRAP
  /audit test-bootstrap  Generate test suite for untested codebase

  UTILITIES
  /audit report          Regenerate findings report from last audit
  /checkpoint            Show checkpoint status

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Type any command to begin. /audit to see this again.
```

---

## Tri-Agent Architecture

```
CODEBASE
    │
    ▼
┌──────────┐
│ AUDITOR  │  Sweeps for problems
│          │  Output: findings report with severity + location
└────┬─────┘
     │
     ▼ (findings)
┌──────────┐
│  FIXER   │  Proposes concrete code changes per finding
│          │  Output: diffs/patches per finding
└────┬─────┘
     │
     ▼ (fixes)
┌──────────┐
│ VERIFIER │  Confirms each fix addresses the finding
│          │  Cannot see Fixer's reasoning — only the diff and original finding
│          │  Output: verified/rejected per fix
└──────────┘
```

### Why Three Agents?

1. **Auditor bias**: A single agent that finds AND fixes tends to minimize findings
   it can't easily fix, and over-report findings it already knows the fix for.
   Separating Auditor from Fixer keeps the audit honest.

2. **Fix theater**: When asked to "fix this code," LLMs commonly restructure the
   code cosmetically without actually solving the underlying problem. A separate
   Verifier that re-reads the original finding and the diff catches this — it asks
   "does this diff actually prevent the vulnerability / fix the bug / solve the
   performance issue?" without being influenced by the Fixer's explanation.

3. **Scope creep**: A fixer will "improve" adjacent code while fixing a finding,
   introducing unreviewed changes. The Verifier flags scope creep: "This diff
   changes 40 lines but the finding was about 3 lines. The extra changes need
   their own review."

---

## Phase 1: Auditor Agent

The Auditor sweeps the codebase and produces findings. This is a read-only agent —
it never modifies code.

### Category Sweeps

Run each applicable category. Skip categories that don't apply (e.g., skip UX for
a pure API project).

#### 1a. Security Sweep

Read `references/security-checklist.md` for the full checklist.

| Check | Severity |
|---|---|
| Hardcoded secrets (API keys, tokens, passwords in source) | CRITICAL |
| SQL injection (string concatenation in queries) | CRITICAL |
| Auth bypass (missing middleware on protected routes) | CRITICAL |
| XSS vectors (unescaped user input in HTML/JSX) | HIGH |
| CORS misconfiguration (wildcard with credentials) | HIGH |
| Missing rate limiting on auth endpoints | HIGH |
| Vulnerable dependencies (known CVEs) | MEDIUM-HIGH |
| Missing input validation | MEDIUM |

#### 1b. Performance Sweep

| Check | Severity |
|---|---|
| N+1 queries (DB call inside loop) | HIGH |
| Missing indexes (frequent WHERE columns, no index) | MEDIUM |
| Bundle bloat (importing entire library for one function) | MEDIUM |
| Synchronous blocking in async context | HIGH |
| Unbounded list queries (no pagination) | MEDIUM |

#### 1c. Code Quality Sweep

| Check | Severity |
|---|---|
| Dead code (unused exports, unreachable branches) | LOW |
| Complexity hotspots (functions > 50 lines, cyclomatic > 10) | MEDIUM |
| Missing error handling (bare catch, swallowed errors) | MEDIUM |
| Type safety gaps (`any` types, missing null checks) | MEDIUM |
| Duplication (copy-pasted logic) | MEDIUM |
| TODO/FIXME/HACK markers | LOW |

#### 1d. Configuration & DevOps Sweep

| Check | Severity |
|---|---|
| Missing .env.example | MEDIUM |
| No .gitignore or missing entries | HIGH |
| No type checking (TS without strict mode) | MEDIUM |
| Missing CI/CD | MEDIUM |
| Stale dependencies | LOW |

#### 1e. UX & Accessibility Sweep

Read `references/ux-audit-checklist.md` for the full checklist.

| Check | Severity |
|---|---|
| Color contrast below 4.5:1 | HIGH |
| Missing form labels | HIGH |
| Div buttons (non-semantic click handlers) | MEDIUM |
| Missing keyboard navigation | HIGH |
| Missing loading/empty/error states | MEDIUM |
| Hardcoded colors/spacing (not using tokens) | MEDIUM |
| Non-responsive components | MEDIUM |

### Cross-Cutting Analysis

After individual sweeps:
1. **Error handling consistency** — same patterns everywhere?
2. **Auth coverage** — all write/user-specific routes protected?
3. **Type pipeline integrity** — types flow DB → API → frontend?
4. **Test coverage gaps** — critical flows tested?

### Finding Format

```markdown
### [F-001] [Short title]

**Severity:** CRITICAL | HIGH | MEDIUM | LOW
**Category:** security | performance | quality | config | ux
**Location:** `src/api/auth.ts:42-58`
**Fix effort:** S (< 30 min) | M (30 min - 2 hr) | L (2+ hr)

**Problem:**
[2-3 sentences: what's wrong and why it matters]

**Evidence:**
[Code snippet or command output]
```

### Audit Report

```markdown
# Code Audit Report — [project]

**Scope:** [full | security | perf | quality | ux | pre-deploy]
**Findings:** [count by severity]
**Overall health:** [A-F with justification]

## Findings (ordered by severity, then fix effort)
[findings...]

## Recommended Fix Order
[Numbered list considering dependencies between fixes]
```

---

## Phase 2: Fixer Agent (`/audit fix <id>` or `/audit fix-all`)

The Fixer takes audit findings and produces concrete code changes. It reads the
finding, reads the relevant source code, and produces a diff.

### Fixer Persona

The Fixer is a senior engineer focused on surgical precision:
- **Minimal diff.** Fix exactly the finding, nothing more. Don't "improve" adjacent code.
- **Preserve style.** Match the existing codebase's formatting, naming, patterns.
- **Test the fix.** If tests exist, run them after the fix to confirm no regressions.
- **Explain the fix.** Brief comment in the diff or 1-2 sentences of rationale.

### Fix Output Format

For each finding:

```markdown
## Fix: [F-001] [Short title]

### Diff
```diff
--- a/src/api/auth.ts
+++ b/src/api/auth.ts
@@ -42,5 +42,8 @@
-  const query = `SELECT * FROM users WHERE email = '${email}'`;
+  const query = `SELECT * FROM users WHERE email = ?`;
+  const result = await db.prepare(query).bind(email).first();
```

### Rationale
Parameterized query prevents SQL injection. Using D1's `.bind()` ensures
the email is properly escaped.

### Tests affected
- [x] Existing tests still pass
- [x] No new test needed (parameterization is the fix)

### Files changed
- `src/api/auth.ts` (1 file, +2 lines, -1 line)
```

### Fix-All Workflow (`/audit fix-all`)

Run the full loop on all findings:

1. **Auditor** produces findings report
2. **Fixer** processes each finding in recommended fix order
3. Group related fixes that touch the same file
4. Apply fixes sequentially, running tests after each group
5. **Verifier** reviews all applied fixes
6. Report: X findings fixed, Y verified, Z rejected

---

## Phase 3: Verifier Agent

The Verifier confirms that fixes actually address findings. It has **isolated context**:
it reads the original finding and the diff, but NOT the Fixer's reasoning or exploration.

### Verifier Persona

The Verifier is a skeptical code reviewer who has seen too many "fixes" that don't fix:
- **Read the finding first.** Understand what the problem IS before looking at the fix.
- **Read the diff literally.** Does this diff prevent the vulnerability? Fix the bug?
  Improve the performance? Or did it just move code around?
- **Check for scope creep.** If the finding was about 3 lines and the diff changes 40,
  the extra changes need justification.
- **Check for regressions.** Did the fix break something that was working?
- **Check for incomplete fixes.** SQL injection on line 42 is fixed, but lines 67 and
  91 have the same pattern — those are still vulnerable.

### Verification Report

```markdown
## Verification — Fix [F-001]

### Finding: [original finding title]
### Fix: [brief description of what the diff does]

### Verdict: VERIFIED / REJECTED / PARTIAL

### Analysis
- Does the diff address the finding? [Yes/No/Partially]
- Scope: [Surgical / Acceptable / Scope creep detected]
- Regressions: [None detected / Potential issue at line X]
- Completeness: [Fix covers all instances / N similar patterns still unfixed]

### If REJECTED:
[Specific reason and guidance for the Fixer to try again]
```

### Verification Outcomes

| Verdict | Meaning | Action |
|---|---|---|
| VERIFIED | Fix correctly addresses the finding | Mark finding as resolved |
| PARTIAL | Fix addresses part of the issue | Feed back to Fixer with specifics |
| REJECTED | Fix doesn't solve the problem or introduces new issues | Feed back to Fixer, try again |

### Iteration

If a fix is REJECTED or PARTIAL:
1. Verifier's report is fed to the Fixer (not the original finding — the Fixer already has that)
2. Fixer produces a revised diff
3. Verifier re-evaluates
4. Max 2 rounds per finding. If still rejected, escalate to user.

---

## Audit Modes (Quick Reference)

| Mode | Sweeps | Tri-Agent | Best for |
|---|---|---|---|
| `/audit full` | All 5 | Auditor only | First audit, periodic health check |
| `/audit security` | 1a + auth cross-cut | Auditor only | Pre-deploy, after auth changes |
| `/audit perf` | 1b | Auditor only | Performance investigation |
| `/audit quality` | 1c | Auditor only | Tech debt assessment |
| `/audit ux` | 1e | Auditor only | Before UAT, UX health check |
| `/audit pre-deploy` | 1a + 1b + 1d | Auditor only | Deploy gate |
| `/audit fix <id>` | — | Fixer + Verifier | Fix one specific finding |
| `/audit fix-all` | All applicable | All three agents | Full find-fix-verify cycle |
| `/audit verify` | — | Verifier only | Re-verify previous fixes |

---

## Test Bootstrap (`/audit test-bootstrap`)

Generate a starter test suite for untested codebases. Not a quality audit —
a bootstrapping operation.

Process:
1. Scan for existing test infra. If none: set up Vitest (TS) or pytest (Python).
2. Identify highest-value targets: auth, API endpoints, validation, core logic.
3. Generate test files: 1 happy-path + 1 error-path per function/endpoint.
4. Run generated tests to verify they pass.
5. Report: X files, Y assertions, Z% of public API covered.

Output: actual test files written to the project, not a report.

---

## Checkpoint Integration

### Checkpoint Location
`{project-dir}/.checkpoints/code-auditor.checkpoint.json`

### When to Write

| Event | What to Save |
|---|---|
| Audit started | Scope, mode, file count |
| Each category sweep complete | Findings from that category |
| Full report generated | Finding count by severity, grade |
| Fix applied | Finding ID, diff summary, files changed |
| Fix verified/rejected | Verification verdict per finding |
| Fix-all complete | Summary: fixed, verified, rejected counts |

### skill_state

```json
{
  "mode": "fix-all",
  "findings_total": 22,
  "findings_by_severity": { "critical": 1, "high": 4, "medium": 11, "low": 6 },
  "grade": "C+",
  "fixes_applied": 5,
  "fixes_verified": 4,
  "fixes_rejected": 1,
  "current_finding": "F-006"
}
```

### Cross-Skill Reads

| Reads from | Why |
|---|---|
| reverse-spec | Stack, architecture, file inventory → skip re-scanning |
| tri-dev | Sprint scores, known issues → don't re-report |
| stack-forge | Typed pipeline standard → grade against |

| Read by | Why |
|---|---|
| deploy-ops | Finding count, grade → deploy gate |
| git-ops | Report path → include in PR |
| tri-dev | Findings → pre-seed evaluator |
| ux-engineer | Component health → UX audit context |

---

## Principles

1. **Every finding cites a file and line.** Vague findings are worthless.
2. **Severity is about impact, not aesthetics.** Auth bypass is CRITICAL even if the
   code is clean. Missing semicolon is not HIGH.
3. **Fixes must be verified.** An unverified fix is a hope, not a solution.
4. **Minimal diffs.** Fix the finding, nothing more. Scope creep in fixes is a bug.
5. **Don't re-report known issues.** Check tri-dev and prior audit checkpoints.
6. **Grade honestly.** A C is a C. Don't inflate.
7. **Skepticism is the Verifier's job.** The Fixer assumes their fix works. The
   Verifier assumes it doesn't. This tension produces real quality.
