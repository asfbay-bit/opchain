---
name: git-ops
description: >
  Git workflow: branch, commit, PR, sync. Use for /git, /commit, /pr, /push,
  "commit this", "push to git", "create a PR", "sync to repo", or any git
  operation. Trigger liberally.
---

# Git Ops

**On first invocation, read `references/orchestrator.md` and follow its welcome protocol.**

Move code from Claude's workspace to a git repository with proper branch management,
commit structure, and PR descriptions. This is the bridge between "Claude built it"
and "it's in version control."

## /git-ops — Command Reference

When the user types `/git-ops`, display this menu:

```
GIT OPS COMMANDS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  WORKFLOW
  /git-init         Clone repo + set up workspace for a project
  /git-branch       Create a feature branch from convention
  /git-commit       Stage + commit with structured message
  /git-pr           Generate PR description from commits/checkpoint
  /git-push         Push branch to remote
  /git-sync         Full workflow: branch → commit → push → PR

  UTILITIES
  /git-status       Show current branch, staged changes, remote state
  /git-diff         Show what's changed since last commit
  /git-convention   Show/set naming conventions for this project
  /checkpoint       Show checkpoint status

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Type any command to begin. /git-ops to see this again.
```

---

## How This Skill Works

```
CLAUDE WORKSPACE                    GIT REPO
/home/claude/project/               github.com/user/project
                                    
  Built files          ──────►      Feature branch
  + checkpoint data    ──────►      Structured commits
  + audit report       ──────►      PR description
```

The typical flow:
1. Clone the user's repo (or confirm it's already cloned)
2. Create a feature branch following project conventions
3. Copy/move built files into the repo working tree
4. Make structured commits (one per logical unit)
5. Push the branch
6. Generate a PR description from the checkpoint + commit log

---

## Phase 0: Repository Setup (/git-init)

### First Time

```bash
# Clone the repo
git clone <repo-url> /home/claude/<project-name>
cd /home/claude/<project-name>

# Verify remote
git remote -v

# Check default branch
git symbolic-ref refs/remotes/origin/HEAD | sed 's@^refs/remotes/origin/@@'
```

### Returning (repo already cloned)

```bash
cd /home/claude/<project-name>
git fetch origin
git checkout main && git pull origin main
```

### Authentication

Git operations require auth. Check in this order:

1. **SSH key** — `ls ~/.ssh/id_*` (preferred for push)
2. **Git credential helper** — `git config credential.helper`
3. **GitHub token** — check env `GITHUB_TOKEN` or `GH_TOKEN`
4. **Ask the user** — "I need git push access. Can you provide a GitHub token
   or set up SSH?"

Store auth method in the checkpoint so future sessions don't re-ask.

---

## Branch Naming Convention

### Default Convention

```
<type>/<short-description>

Types:
  feat/     New feature
  fix/      Bug fix
  refactor/ Code restructure (no behavior change)
  chore/    Dependencies, config, tooling
  docs/     Documentation only
  test/     Test additions or fixes
  deploy/   Deployment-related changes
```

Examples:
- `feat/pintrack-substance-module`
- `fix/auth-session-expiry`
- `chore/update-wrangler-config`
- `deploy/add-staging-workflow`

### Convention from Checkpoint

If an app-architect or tri-dev checkpoint exists, derive the branch name from it:
- Sprint 1 build → `feat/sprint-1-auth-flow`
- Code audit fix → `fix/audit-f001-rate-limiting`
- Deploy setup → `deploy/ci-cd-pipeline`

### /git-convention

Set or view the project's naming conventions:

```bash
# Store in project config
cat > .git-ops-config.json << 'EOF'
{
  "branch_prefix": "feat|fix|refactor|chore|docs|test|deploy",
  "commit_format": "conventional",
  "default_base": "main",
  "pr_template": true,
  "auto_lint_before_commit": true
}
EOF
```

---

## Commit Structure (/git-commit)

### Conventional Commits

```
<type>(<scope>): <description>

[optional body]

[optional footer]
```

| Type | When |
|---|---|
| `feat` | New feature for the user |
| `fix` | Bug fix |
| `refactor` | Code change that doesn't fix a bug or add a feature |
| `chore` | Tooling, deps, config |
| `docs` | Documentation |
| `test` | Adding or fixing tests |
| `ci` | CI/CD changes |
| `style` | Formatting (no logic change) |

### Commit Granularity

One commit per logical unit of work. Rules of thumb:

| Change Size | Commit Strategy |
|---|---|
| Single file fix | 1 commit |
| New component (file + test + styles) | 1 commit |
| New feature (multiple files) | 1 commit per layer: schema → API → frontend → tests |
| Full sprint | 3-6 commits following the build order |
| Config/tooling changes | 1 commit, separate from feature work |

### Auto-Commit from Tri-Dev Sprints

When tri-dev completes a sprint, git-ops can auto-structure commits:

```bash
# Read the sprint contract for commit scoping
# Each contract deliverable becomes one commit

# Example for Sprint 1: Auth
git add src/db/migrations/ src/db/schema.ts
git commit -m "feat(db): add users and sessions tables"

git add src/auth/ src/middleware/session.ts
git commit -m "feat(auth): implement WebAuthn passkey flow"

git add src/auth/__tests__/ tests/
git commit -m "test(auth): add unit + integration tests for passkey auth"
```

### Pre-Commit Checks

Before committing, if the project has tooling:

```bash
# Type check
npx tsc --noEmit 2>/dev/null && echo "✅ Types OK" || echo "⚠️ Type errors"

# Lint
npx eslint . --max-warnings 0 2>/dev/null && echo "✅ Lint OK" || echo "⚠️ Lint warnings"

# Tests
npm test 2>/dev/null && echo "✅ Tests pass" || echo "⚠️ Test failures"
```

If any check fails, warn the user but don't block — they may want to commit WIP.

---

## PR Description (/git-pr)

### Auto-Generated from Context

Pull from all available sources to build a comprehensive PR description:

1. **Commit log** — `git log main..HEAD --oneline`
2. **Tri-dev checkpoint** — sprint contract, evaluator scores
3. **Code-auditor checkpoint** — findings addressed, remaining issues
4. **App-architect checkpoint** — which roadmap tasks this covers

### PR Template

```markdown
## Summary

[2-3 sentences: what this PR does and why]

## Changes

[Auto-generated from commit messages, grouped by type]

### Features
- [feat commits]

### Fixes
- [fix commits]

### Other
- [remaining commits]

## Testing

- [ ] Unit tests pass (`npm test`)
- [ ] Type check passes (`tsc --noEmit`)
- [ ] Manual testing completed
[If tri-dev: "Evaluated by tri-dev evaluator: X.X/10 (sprint N)"]

## Audit Status

[If code-auditor ran: "Pre-deploy audit: Grade [X], [N] findings ([M] addressed in this PR)"]
[If not: "No code audit run — consider `/audit pre-deploy` before merging"]

## Deployment Notes

[Any migration steps, env var additions, or config changes needed]
[Auto-detected from: new migration files, .env.example changes, wrangler.toml changes]
```

### Creating the PR

```bash
# If gh CLI is available
gh pr create --title "[type]: [description]" --body-file /tmp/pr-description.md

# If not, output the description for the user to paste
echo "PR description saved to: /mnt/user-data/outputs/pr-description.md"
echo "Create the PR manually and paste this description."
```

---

## Full Sync Workflow (/git-sync)

One command that runs the entire flow:

```
/git-sync [description]
```

1. **Detect context** — read checkpoints for project, skill, and current state
2. **Determine branch name** — from checkpoint or description
3. **Create branch** — `git checkout -b <branch>`
4. **Stage changes** — intelligently stage (skip build artifacts, node_modules)
5. **Structure commits** — group by logical unit
6. **Run pre-commit checks** — lint, types, tests (warn, don't block)
7. **Push** — `git push -u origin <branch>`
8. **Generate PR description** — from all available context
9. **Create PR** — via gh CLI or output for manual creation

At each step, show progress. If any step needs user input, ask once and continue.

### Post-Sync Handoff

After `/git-sync` completes successfully:
- If a deploy-ops config exists for this project, suggest:
  "Changes pushed. Run `/deploy staging` to deploy to staging?"
- If no deploy-ops config exists, suggest:
  "Changes pushed. Run `/deploy init` to set up deployment, or `/audit pre-deploy` for a quality check."

---

## Project Governance Awareness

If a `GOVERNANCE.md` file exists in the project root (generated by app-architect or
the project-governance skill), read it before committing. Respect:
- **Naming conventions** — file naming, branch naming overrides
- **Directory structure** — where new files should be placed
- **Version tracking** — which documents are master copies vs. working drafts
- **Git strategy** — branching model (if different from git-ops defaults)

If governance conventions conflict with git-ops defaults, governance wins — it's
project-specific, git-ops defaults are generic.

---

## Checkpoint Integration

### Checkpoint Location
`{project-dir}/.checkpoints/git-ops.checkpoint.json`

### When to Write

| Event | What to Save |
|---|---|
| Repo cloned/verified | Repo URL, default branch, auth method |
| Branch created | Branch name, base branch, purpose |
| Commits made | Commit SHAs, messages, file counts |
| Push completed | Remote URL, branch pushed, timestamp |
| PR created | PR URL, PR number |

### context_primer Template

```json
{
  "key_decisions": [
    "Repo: github.com/user/aidops-core",
    "Auth: SSH key",
    "Convention: conventional commits, feat/fix/chore prefixes",
    "Last push: feat/pintrack-module → origin, 6 commits"
  ],
  "generated_files": [
    "pr-description.md"
  ]
}
```

### Cross-Skill Reads

| Reads from | Why |
|---|---|
| tri-dev | Sprint contract → commit scoping, eval scores → PR description |
| code-auditor | Audit grade → PR description, findings → commit grouping |
| app-architect | Roadmap tasks → PR description, phase → branch naming |
| deploy-ops | Deploy status → PR deployment notes |

---

## .gitignore Enforcement

When committing, always verify these are gitignored:

```
node_modules/
.env
.env.local
dist/
build/
.wrangler/
.checkpoints/          # Checkpoint protocol files
*.checkpoint.json.bak  # Archived checkpoints
.git-ops-config.json   # Local git-ops config
```

If `.gitignore` is missing entries, add them in a separate `chore: update .gitignore`
commit before the feature commits.

---

## Principles

1. **One logical change per commit.** Not one file per commit. Not one sprint per commit.
   The unit is "one thing a reviewer can understand in isolation."
2. **Branch names tell a story.** `feat/sprint-2-crud-api` beats `update-stuff`.
3. **PR descriptions are for future-you.** Six months from now, this PR title + description
   should explain why this change exists without reading the code.
4. **Never force-push main.** Feature branches can be force-pushed (rebased). Main cannot.
5. **Commits are cheap, reverts are cheaper.** Small, atomic commits make rollbacks surgical.
6. **Auth setup happens once.** Store the method in checkpoint, never re-ask.
